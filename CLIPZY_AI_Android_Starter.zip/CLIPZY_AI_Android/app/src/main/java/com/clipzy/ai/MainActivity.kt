package com.clipzy.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF111827)
private val Blue = Color(0xFF258BFF)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClipzyApp() }
    }
}

@Composable
fun ClipzyApp() {
    var videoUrl by remember { mutableStateOf("") }
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Ready to create your first short") }
    var showInfo by remember { mutableStateOf(false) }
    var clipsWanted by remember { mutableIntStateOf(5) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedVideo = uri
            status = "Video selected. AI processing needs the CLIPZY backend."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).background(Blue, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.ContentCut, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("CLIPZY AI", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("TURN LONG VIDEOS INTO SHORTS", fontSize = 10.sp, color = Muted, letterSpacing = 1.2.sp)
                    }
                    IconButton(onClick = { showInfo = !showInfo }) {
                        Icon(Icons.Default.Info, "Info", tint = Muted)
                    }
                }

                if (showInfo) {
                    InfoCard()
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Create viral-style clips", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Drop a video link or choose a video from your phone.", color = Muted)
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Label("YOUTUBE VIDEO LINK")
                        OutlinedTextField(
                            value = videoUrl,
                            onValueChange = { videoUrl = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Paste YouTube URL", color = Muted) },
                            leadingIcon = { Icon(Icons.Default.Link, null, tint = Blue) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Blue,
                                unfocusedBorderColor = Color(0xFF334155),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        Button(
                            onClick = {
                                status = if (videoUrl.startsWith("https://") || videoUrl.startsWith("http://")) {
                                    "Link saved. Connect an authorized video-ingestion backend to analyze it."
                                } else "Enter a valid video URL first."
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.SmartAutoAwesome, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Analyze YouTube link")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HorizontalDivider(Modifier.weight(1f), color = Color(0xFF334155))
                            Text("  OR  ", color = Muted, fontSize = 11.sp)
                            HorizontalDivider(Modifier.weight(1f), color = Color(0xFF334155))
                        }
                        OutlinedButton(
                            onClick = { picker.launch(arrayOf("video/*")) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (selectedVideo == null) "Upload video from phone" else "Choose another video")
                        }
                        selectedVideo?.let {
                            Text("Selected: ${it.lastPathSegment ?: "Video file"}", color = Blue, fontSize = 12.sp)
                        }
                    }
                }

                Text("YOUR CLIP SETTINGS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VideoLibrary, null, tint = Blue, modifier = Modifier.size(21.dp))
                            Spacer(Modifier.width(12.dp))
                            Text("Number of clips", modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Text("$clipsWanted clips", color = Blue, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = clipsWanted.toFloat(),
                            onValueChange = { clipsWanted = it.toInt().coerceIn(1, 10) },
                            valueRange = 1f..10f,
                            steps = 8,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("1 clip", color = Muted, fontSize = 11.sp)
                            Text("10 clips", color = Muted, fontSize = 11.sp)
                        }
                        SettingRow(Icons.Default.Timer, "Clip duration", "30–40 seconds")
                        SettingRow(Icons.Default.PhoneAndroid, "Aspect ratio", "9:16 · 1080 × 1920")
                        SettingRow(Icons.Default.Subtitles, "Captions", "Auto · Hindi / Hinglish / English")
                        SettingRow(Icons.Default.Bolt, "Opening hook", "First 2 seconds")
                        SettingRow(Icons.Default.AutoAwesome, "Moment detection", "Engaging moments + potential score")
                    }
                }

                Text("AI VIRAL POTENTIAL SCORE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Leaderboard, null, tint = Blue)
                            Spacer(Modifier.width(8.dp))
                            Text("Rank your best moments", fontWeight = FontWeight.Bold)
                        }
                        Text("Each generated clip will receive an estimated score out of 100 based on its opening hook, speech/activity, pacing and caption readability.", color = Muted, fontSize = 12.sp)
                        ViralScorePreview("Example clip A", 92, "Strong hook")
                        ViralScorePreview("Example clip B", 84, "Good pacing")
                        ViralScorePreview("Example clip C", 76, "Clear moment")
                        Text("Illustrative preview only — real scores appear after AI analysis. A high score does not guarantee virality.", color = Muted, fontSize = 10.sp)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B30)), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Downloading, null, tint = Blue)
                            Spacer(Modifier.width(8.dp))
                            Text("Export to your phone", fontWeight = FontWeight.Bold)
                        }
                        Text("Generated clips will be saved to your device. Export and download become available after the video-processing service is connected.", color = Muted, fontSize = 13.sp)
                    }
                }

                Text(status, color = Blue, fontSize = 12.sp)
                Text("CLIPZY AI  •  EARLY BUILD 0.1.0", color = Color(0xFF64748B), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun Label(value: String) {
    Text(value, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(21.dp))
        Spacer(Modifier.width(12.dp))
        Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
        Text(value, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ViralScorePreview(title: String, score: Int, note: String) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text("$score/100", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        LinearProgressIndicator(
            progress = { score / 100f },
            modifier = Modifier.fillMaxWidth().height(7.dp),
            color = Blue,
            trackColor = Color(0xFF263449)
        )
        Text(note, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun InfoCard() {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Text(
            "This is the Android starter app. Automatic highlight detection, caption generation, reframing and rendering require a secure processing backend. Never paste private API keys into the Android app.",
            Modifier.padding(16.dp), color = Muted, fontSize = 13.sp
        )
    }
}
